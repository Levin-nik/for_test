//
//  PKCEPayloadGenerator.swift
//  T-ID
//
//  Copyright (c) 2024 TBank
//
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
//
//  http://www.apache.org/licenses/LICENSE-2.0
//
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.

import Foundation

final class PKCEPayloadGenerator: IPKCEPayloadGenerator {

    let codeVerifierGenerator: IPKCECodeVerifierGenerator
    let codeChallengeDerivator: IPKCECodeChallengeDerivator

    init(
        codeVerifierGenerator: IPKCECodeVerifierGenerator,
        codeChallengeDerivator: IPKCECodeChallengeDerivator
    ) {
        self.codeVerifierGenerator = codeVerifierGenerator
        self.codeChallengeDerivator = codeChallengeDerivator
    }

    func generatePayload() throws -> PKCECodePayload {
        let codeVerifier = codeVerifierGenerator.generateCodeVerifier()
        let codeChallenge = try codeChallengeDerivator.deriveCodeChallenge(using: codeVerifier)

        return PKCECodePayload(
            verifier: codeVerifier,
            challenge: codeChallenge,
            challengeMethod: codeChallengeDerivator.codeChallengeMethod
        )
    }
}
