#
#  Be sure to run `pod spec lint SPaySDK.podspec' to ensure this is a
#  valid spec and to remove all comments including this before submitting the spec.
#
#  To learn more about Podspec attributes see https://guides.cocoapods.org/syntax/podspec.html
#  To see working Podspecs in the CocoaPods repo see https://github.com/CocoaPods/Specs/
#

Pod::Spec.new do |spec|
  spec.name         = "SPaySDKiOS"
  spec.version      = "3.2.6"
  spec.summary      = "SDK for payments in online shops."
  spec.description  = "This pod helps integrate payments in online shops."
  spec.homepage     = "https://gitverse.ru/sberpay/SPaySDKCocoa-IOS.git"
  spec.license      = { :type => "MIT", :file => "LICENSE" }
  spec.authors      = {
    "AlexanderIpatov" => "alexanderipatov1997@gmail.com",
    "FarafonovK" => "mcfamous100@gmail.com",
    "SergeyGladkiy" => "neofun93@gmail.com"
  }

  spec.platform     = :ios, "14.0"

  spec.source       = { :git => "https://gitverse.ru/sberpay/SPaySDKCocoa-IOS.git", :tag => spec.version.to_s }
  spec.vendored_frameworks = "SPaySdk.xcframework"
  
end
